package com.otto.paulus.footballmatchschedule.model

data class EventDetailResponse (
        val events: List<EventDetail>
)